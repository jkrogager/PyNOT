from PyNOT import *
import extraction
from extraction import *
import alfosc
import calibs
from sens import sensitivity

print ""
print "   PyNOT  v. %r " % PyNOT.__version__
print ""
print "   Data Reduction Tools for ALFOSC"
print "   Mounted at the Nordic Optical Telescope"
print ""
print "   Written by Jens-Kristian Krogager"
print "   Institut d'Astrophysique de Paris"
print "   March 2017"
print ""
