import glob
from os.path import basename

path = '/Users/krogager/coding/PyNOT'

grism_translate = {'Grism_#3': 'grism3',
                   'Grism_#4': 'grism4',
                   'Grism_#5': 'grism5',
                   'Grism_#6': 'grism6',
                   'Grism_#7': 'grism7'}


slits = ['Ech_0.7', 'Ech_0.8', 'Ech_1.0', 'Ech_1.2', 'Ech_1.6',
         'Ech_1.8', 'Ech_2.2', 'Pol_1.0', 'Pol_1.4', 'Pol_1.8',
         'Slit_0.4', 'Slit_0.5', 'Slit_0.75', 'Slit_1.0',
         'Slit_1.3', 'Slit_1.8', 'Slit_2.5', 'Slit_10.0',
         'Vert_0.5', 'Vert_0.75', 'Vert_0.9', 'Vert_1.3',
         'Vert_1.8', 'Vert_10.0', 'VertOff_0.5', 'VertOff_0.8',
         'VertOff_1.0', 'VertOff_1.3', 'VertOff_1.9', 'VertOff_8.8']


# --- Data taken from: ftp://ftp.stsci.edu/cdbs/current_calspec/
standard_star_files = glob.glob(path + '/calib/std/*.dat')
standard_star_files = [basename(fname) for fname in standard_star_files]
standard_stars = [fname.strip('.dat') for fname in standard_star_files]

# Old static implementation:
# standard_stars = ['bd174708', 'bd262606',
#                   'bd332642', 'feige110',
#                   'feige34', 'gd153', 'gd71',
#                   'hd19445', 'hd84937', 'hd93521',
#                   'he3', 'hiltner600', 'wolf1346']


standard_star_names = {'SP0305+261': 'HD19445',
                       'SP0644+375': 'He3',
                       'SP0946+139': 'HD84937',
                       'SP1036+433': 'Feige34',
                       'SP1045+378': 'HD93521',
                       'SP1446+259': 'BD262606',
                       'SP1550+330': 'BD332642',
                       'SP2032+248': 'Wolf1346',
                       'SP2209+178': 'BD174708',
                       'SP2317-054': 'Feige110',
                       'SP0642+021': 'Hiltner600',
                       'GD71': 'GD71',
                       'GD153': 'GD153'}
